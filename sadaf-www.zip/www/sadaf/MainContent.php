<?php
	include "header.inc.php";
?>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<style type="text/css" > INPUT, SELECT { font-family: Tahoma }'.
</style>
<link rel="stylesheet"  href="css/login.css" type="text/css">
</head>
<body  dir=rtl link="#0000FF" alink="#0000FF" vlink="#0000FF">
</body>
