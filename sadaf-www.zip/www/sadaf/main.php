<?php
include('header.inc.php');
?>
<html dir="rtl">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="css/main.css">
</head>
   <frameset cols="*,280px" >
   <frame id=MainContent name=MainContent src="MainContent.php">
   <frame id=Menu name=Menu src="Menu.php">   
   </frameset>
	<body >
   </body>
</html>