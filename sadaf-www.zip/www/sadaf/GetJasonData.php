<?php
	include "header.inc.php";
	echo "[";
    echo "{ \"value\": 1, \"text\": \"Google Cloud Platform\" },\r\n";
	echo "{ \"value\": 2, \"text\": \"Google3\" }\r\n";
	echo "]";
?>