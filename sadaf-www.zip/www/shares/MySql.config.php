<?php
	define('MYSQL_NAME', 'localhost');
	define('MYSQL_USERNAME', 'user1');
	define('MYSQL_PASSWORD', 'user1');
	define('MYSQL_DATABASE', 'sadaf');
?>
